#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Exercise production query/unmap serialization with real host threads."""
import argparse
import pathlib
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=pathlib.Path)
args = parser.parse_args()
source = args.source.read_text()
helper = re.search(r'^Aperture \*\nget_aperture\([^)]*\)\n\{.*?^}', source, re.M | re.S).group()
functions = []
for name in ('get_aperture_info', 'unmap_aperture'):
    match = re.search(r'^static status_t\n' + name + r'\([^)]*\)\n\{.*?^}', source, re.M | re.S)
    if match is None:
        raise SystemExit('missing production function: ' + name)
    functions.append(match.group())
prefix = r'''
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <mutex>
#include <thread>
using status_t = int;
using aperture_id = int;
constexpr int B_OK = 0, B_ENTRY_NOT_FOUND = -2;
struct aperture_info { int value; };
static std::mutex gate;
static std::condition_variable changed;
static bool entered, releaseQuery, teardownBlocked, destroyed;
static thread_local bool teardownThread;
struct TestLock { std::mutex mutex; };
static TestLock sLock;
struct Autolock {
 TestLock& lock;
 explicit Autolock(TestLock& l):lock(l) {
  if (teardownThread && &l == &sLock) {
   if (!l.mutex.try_lock()) {
    { std::lock_guard<std::mutex> guard(gate); teardownBlocked = true; }
    changed.notify_all(); l.mutex.lock();
   }
  } else l.mutex.lock();
 }
 ~Autolock() { lock.mutex.unlock(); }
};
struct Aperture {
 TestLock lock;
 TestLock& Lock() { return lock; }
 int GetInfo(aperture_info* info) {
  std::unique_lock<std::mutex> guard(gate);
  entered = true; changed.notify_all();
  assert(changed.wait_for(guard,std::chrono::seconds(5),[]{return releaseQuery;}));
  assert(!destroyed); info->value = 73; return B_OK;
 }
 int DeleteAllMemory() { return B_OK; }
 void MarkCleanupPending() {}
 ~Aperture() { std::lock_guard<std::mutex> guard(gate); destroyed = true; }
};
struct Registry {
 Aperture* value = nullptr;
 Aperture* Lookup(int id) { return id == 1 ? value : nullptr; }
 void Remove(Aperture* item) { assert(value == item); value = nullptr; }
};
static Registry sApertureHashTable;

'''
suffix = r'''
int main() {
 for (unsigned round = 0; round < 100; round++) {
  entered = releaseQuery = teardownBlocked = destroyed = false;
  sApertureHashTable.value = new Aperture;
  aperture_info info{}; int queryResult = -99, teardownResult = -99;
  std::thread reader([&]{ queryResult = get_aperture_info(1,&info); });
  { std::unique_lock<std::mutex> guard(gate);
    assert(changed.wait_for(guard,std::chrono::seconds(5),[]{return entered;})); }
  std::thread teardown([&]{ teardownThread = true; teardownResult = unmap_aperture(1); });
  { std::unique_lock<std::mutex> guard(gate);
    assert(changed.wait_for(guard,std::chrono::seconds(5),[]{return teardownBlocked;}));
    assert(!destroyed); releaseQuery = true; }
  changed.notify_all(); reader.join(); teardown.join();
  assert(queryResult == B_OK && info.value == 73 && teardownResult == B_OK && destroyed);
  assert(get_aperture_info(1,&info) == B_ENTRY_NOT_FOUND);
  assert(unmap_aperture(1) == B_ENTRY_NOT_FOUND);
 }
 puts("100 threaded production query/unmap lifetime rounds passed");
}
'''
with tempfile.TemporaryDirectory(prefix='gart-threaded-') as directory:
    tmp = pathlib.Path(directory)
    (tmp/'test.cpp').write_text(prefix + helper + '\n'.join(functions) + suffix)
    subprocess.run(['g++', '-std=c++17', '-pthread', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', str(tmp/'test.cpp'), '-o', str(tmp/'test')], check=True)
    subprocess.run([str(tmp/'test')], check=True, timeout=30)
